package com.example.emlakburada.gateway.enums;

public enum RealEstateStatus {
    FIRST_USE,
    CLEAN_USE,
    
}
