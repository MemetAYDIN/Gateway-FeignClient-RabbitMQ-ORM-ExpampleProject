package com.example.emlakburada.gateway.enums;

public enum UserType {

    COMPANY,
    INDIVIDUAL,
	
}
