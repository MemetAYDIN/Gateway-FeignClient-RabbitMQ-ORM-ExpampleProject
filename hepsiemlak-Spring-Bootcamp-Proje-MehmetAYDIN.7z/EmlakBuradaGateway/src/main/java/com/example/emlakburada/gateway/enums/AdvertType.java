package com.example.emlakburada.gateway.enums;

public enum AdvertType {
    RENT,
    SALE,
    DAILY_RENT
}
