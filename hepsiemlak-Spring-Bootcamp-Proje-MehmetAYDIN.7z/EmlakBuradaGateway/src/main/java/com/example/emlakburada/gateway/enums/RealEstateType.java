package com.example.emlakburada.gateway.enums;

public enum RealEstateType {
    APARTMENT_ROOM,
    APARTMENT, 
    DETACHED_HOUSE,
    HOUSE_WITH_GARDEN, 
    FARM_HOUSE
}
