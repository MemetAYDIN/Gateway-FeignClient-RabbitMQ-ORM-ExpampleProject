package com.example.emlakburada.gateway.enums;

public enum AdvertStatus {
	ACTIVE,
	PASSIVE,
	IN_REVIEW
}
