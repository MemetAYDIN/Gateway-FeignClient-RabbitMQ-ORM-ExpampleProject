package com.example.emlakburada.gateway.dto;


import lombok.Data;

@Data
public class EmailMessageDTO {
    private String email;
}
