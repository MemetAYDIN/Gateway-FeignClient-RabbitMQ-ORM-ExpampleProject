package com.example.emlakburada.gateway.enums;

public enum Currency {
    TL,
    USD,
    EUR
}
