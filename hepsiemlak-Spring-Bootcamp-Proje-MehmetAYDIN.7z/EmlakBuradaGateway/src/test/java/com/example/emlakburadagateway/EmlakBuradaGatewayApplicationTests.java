package com.example.emlakburadagateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmlakBuradaGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
