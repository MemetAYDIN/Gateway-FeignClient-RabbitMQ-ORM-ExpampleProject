package com.example.emlak_burada_banner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmlakBuradaBannerApplicationTests {

    @Test
    void contextLoads() {
    }

}
