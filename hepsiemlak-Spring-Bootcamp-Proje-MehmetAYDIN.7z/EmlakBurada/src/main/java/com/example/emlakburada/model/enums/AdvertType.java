package com.example.emlakburada.model.enums;

public enum AdvertType {
    RENT,
    SALE,
    DAILY_RENT
}
