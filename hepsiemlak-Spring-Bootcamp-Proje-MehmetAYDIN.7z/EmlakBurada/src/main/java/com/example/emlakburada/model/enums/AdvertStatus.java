package com.example.emlakburada.model.enums;

public enum AdvertStatus {
	ACTIVE,
	PASSIVE,
	IN_REVIEW
}
