package com.example.emlakburada.model.enums;

public enum RealEstateType {
    APARTMENT_ROOM,
    APARTMENT, 
    DETACHED_HOUSE,
    HOUSE_WITH_GARDEN, 
    FARM_HOUSE
}
