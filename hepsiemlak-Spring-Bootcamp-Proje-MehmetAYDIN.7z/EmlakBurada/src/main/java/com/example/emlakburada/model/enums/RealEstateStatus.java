package com.example.emlakburada.model.enums;

public enum RealEstateStatus {
    FIRST_USE,
    CLEAN_USE,
    
}
