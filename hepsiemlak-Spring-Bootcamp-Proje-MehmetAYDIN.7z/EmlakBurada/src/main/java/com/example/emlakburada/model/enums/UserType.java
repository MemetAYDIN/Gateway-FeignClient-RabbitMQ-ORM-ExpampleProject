package com.example.emlakburada.model.enums;

public enum UserType {

    COMPANY,
    INDIVIDUAL,
	
}
