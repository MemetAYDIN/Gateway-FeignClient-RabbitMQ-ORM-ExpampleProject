package com.example.emlakburada.dto;


import lombok.Data;

@Data
public class EmailMessageDTO {
    private String email;
}
