package com.example.emlakburada.model.enums;

public enum Currency {
    TL,
    USD,
    EUR
}
