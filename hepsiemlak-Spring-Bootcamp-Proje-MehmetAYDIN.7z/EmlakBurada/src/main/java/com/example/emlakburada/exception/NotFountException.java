package com.example.emlakburada.exception;

public class NotFountException extends ServiceException {
    public NotFountException() {
        super(RESOURCE_NOT_FOUND, "Requested resource not found");
    }

    public NotFountException(String errorDescription) {
        super(RESOURCE_NOT_FOUND, errorDescription);
    }
}
