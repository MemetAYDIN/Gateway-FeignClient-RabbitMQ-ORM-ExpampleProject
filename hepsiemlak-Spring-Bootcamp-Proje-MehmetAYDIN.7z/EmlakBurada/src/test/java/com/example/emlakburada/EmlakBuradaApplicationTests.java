package com.example.emlakburada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmlakBuradaApplicationTests {

    @Test
    void contextLoads() {
    }

}
