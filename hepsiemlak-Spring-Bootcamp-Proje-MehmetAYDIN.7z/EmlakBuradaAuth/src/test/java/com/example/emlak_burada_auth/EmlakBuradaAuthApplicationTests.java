package com.example.emlak_burada_auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmlakBuradaAuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
