package com.example.emlakburada.auth.enums;

public enum UserType {
    COMPANY,
    INDIVIDUAL,
}
